import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; 
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ServiceService {

constructor(private http: HttpClient){}
deleteUser(id:any){
return this.http.delete(`this.deleteuser/${id}`)
}

  // getPosts(postData:any):Observable<any>{
  //   return this.http.post(this.urlPost,postData)
  // }
  // getPosts(){
  //   return this.http.post(urlPost,this.postData).subscribe((data:any)=>{
  //     console.log(data);
  //     alert("successfully")
  //   }
  //     )}
  //  url='http://localhost:3000/posts'
  createUser(data:any){
    return this.http.post(this.url,data)
  }

  profileId:string='650d46cecc21b95d68a68a31';
  // gallary:string="PhotoGallery"
  gallary:string="NewsGallery"


  url="http://localhost:3000/profile"
  post_profile(data:any){
    return this.http.post(`${this.url}/${this.profileId}/${this.gallary}`,data)
    // console.log("${this.url}/${this.profileId}")
  }

  update_url="http://localhost:3000/profile/updateOneprofileById/650d46cecc21b95d68a68a31"
  update_Profile(id:any,data:any){
    return this.http.put(`${this.update_url}/${id}`,data)
  }


  update_cuurent(id:any){
return this.http.get(`${this.geturl}`)
  }

  geturl="http://localhost:3000/profile/getAllRegisterUser";
  get_User() {
    return this.http.get(this.geturl)
    
  }
}
