import { Component } from '@angular/core';
import { FormGroup,FormControl,FormArray,FormBuilder} from '@angular/forms'
import { DomSanitizer } from '@angular/platform-browser';
import {OnInit, ChangeDetectorRef } from '@angular/core';
import Swal from 'sweetalert2';
import { ServiceService } from '../service.service';
import { Router,ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',

  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent implements OnInit{
  constructor(private router: Router ,private route: ActivatedRoute,
    public _d: DomSanitizer, private cf: ChangeDetectorRef ,private service :ServiceService ,private formBuilder:FormBuilder)  {}
    
    updateForm: FormGroup = new FormGroup({});
    getAll_data: any = {};
    formUpdated: boolean = false;
    onInputChange() {
      this.formUpdated = true;
    }
    
    updateDataIfNeeded() {
      if (this.formUpdated) {
        this.updateData();
        this.formUpdated = false; // Reset the flag
      }
    }
    
    updateData() {
      // Assuming this.getAll_data contains the updated data
      this.service.updateUserData(this.updateForm.value)
        .subscribe(
          (response) => {
          console.log(response)
            console.log('Data updated successfully:', response);
          },
          (error) => {
            // Handle errors if the data update fails
            console.error('Error updating data:', error);
          }
        );
    }



  // updateForm=new FormGroup({
  //   pname:new FormControl(''),
  //   partyname:new FormControl(''),
  //   email:new FormControl(''),
  //   phoneno:new FormControl(''),
  //   whatsappno:new FormControl(''),
  //   officeloction:new FormControl(' '),
  //   youtube:new FormControl(''),
  //   insta:new FormControl(''),
  //   facebook:new FormControl(''),
  //   twitterId:new FormControl('') ,
  //   info:new FormControl(''),
  //   photo:new FormControl(''),
  //   logo:new FormControl(''),
  //   // descriptions: new FormArray([])
  //   // description:new FormControl('')
   
  
  // })
  
  /*---------------Politician Photo------------------*/
    // imgsrc='assets/image/templet1/customer/profile/profileImage.jpg';
  imgsrc='';
  profilePhoto(e: any) {
    var file = e.srcElement.files[0];
    this.imgsrc = window.URL.createObjectURL(file);
  }

    /*---------------Logo------------------*/
     // imglogo="assets/image/templet1/customer/logo/2.jpg";
    imglogo='';
    Logo(e: any) {
      var file = e.srcElement.files[0];
      this.imglogo = window.URL.createObjectURL(file);
    }
  //get all data back end
photo_gallary_images: any[]=[] ;
news_gallary_images: any[]=[] ; //send parent to child array using props 
PhotoGallaryName:string="PhotoGallery";
NewsGallaryName:string="NewsGallery";
// getAll_data:any[]=[];


ngOnInit(): void {
  this.updateForm = this.formBuilder.group({
    PoliticianName: [''],
    PoliticalPartyName: [''],
    PhoneNumber: [''],
    whatsappno: [''],
    MailId: [''],
    Partyofficelocation: [''],
    InstagramId: [''],
    FecebookId: [''],
    TwitterId: [''],
    YouTubeLink: [''],
    PoliticiansInformation: ['']
    // Add other form controls as needed
  });

  this.loadData();



  this.service.get_User().subscribe((data:any)=>{
    if(Array.isArray(data)){
      this.getAll_data = data;
      for (const item of this.getAll_data) {
        for (const item1 of item.PhotoGallery) {
          this.photo_gallary_images.push(item1);
      }
      for (const item2 of item.NewsGallery) {
        this.news_gallary_images.push(item2);
    }
    }
    }

  })

}
loadData() {
  // Assuming this.getAll_data contains the data from your service
  // You can update the form values with the loaded data
  this.updateForm.patchValue({
    PoliticianName: this.getAll_data.PoliticianName,
    PoliticalPartyName: this.getAll_data.PoliticalPartyName,
    PhoneNumber: this.getAll_data.PhoneNumber,
    whatsappno: this.getAll_data.whatsappno,
    MailId: this.getAll_data.MailId,
    Partyofficelocation: this.getAll_data.Partyofficelocation,
    InstagramId: this.getAll_data.InstagramId,
    FecebookId: this.getAll_data.FecebookId,
    TwitterId: this.getAll_data.TwitterId,
    YouTubeLink: this.getAll_data.YouTubeLink,
    PoliticiansInformation: this.getAll_data.PoliticiansInformation
  });
}

//PoliticalPartylogo & PoliticanPhoto base url
getImageUrl(filename: string): string {
  return `${filename}`;
}
    


/*---------------photo gallery------------------*/
// photoGallery_array=["assets/image/templet1/customer/photo_gallery/img1.jpg","assets/image/templet1/customer/photo_gallery/img2.jpg","assets/image/templet1/customer/photo_gallery/img3.jpg","assets/image/templet1/customer/photo_gallery/img4.jpg","assets/image/templet1/customer/photo_gallery/img5.jpg","assets/image/templet1/customer/photo_gallery/img6.jpg","assets/image/templet1/customer/photo_gallery/img7.jpg","assets/image/templet1/customer/photo_gallery/img8.jpg"]
// url1: any= [];
// photoGallery_array: any[] = []; 
// selectedFiles: File[] = [];
// descriptions: string[] = [];
// public file1: any;
// photosGallery(event:any) {
//   this.file1 = event.target.files && event.target.files.length;
//   if (this.file1 > 0 && this.file1 < 25) {
//     let i: number = 0;  
//     for (const singlefile of event.target.files) {
//       var reader = new FileReader();
//       reader.readAsDataURL(singlefile);
//       this.url1.push(singlefile);
//       this.descriptions.push('')

//       // const descriptionControl = new FormControl('');
//       // const descriptionGroup = this.formBuilder.group({
//       //   description: [''], // Set an initial value for description
//       // });
//       // this.descriptions.push(description || '');
//       // (this.updateform.get('descriptions') as FormArray).push(descriptionControl);
//       // (this.updateform.get('descriptions') as FormArray).push(descriptionGroup);
//       this.cf.detectChanges();
//       i++;
//       reader.onload = (event) => {
//         const urls2 = (<FileReader>event.target).result as string;
//         this.photoGallery_array.push(urls2);
//         this.cf.detectChanges();
//       };
//     }
//       this.selectedFiles =event.target.files
//   }
// }
// toggle (+ -) button
// display=false;
// togglebut(){
//   this.display=!this.display;
// }
// display2=false;
// togglebut2(){
//   this.display2=!this.display2;
// }
/*---------------News gallery------------------*/
// NewsGallery_array=["assets/image/templet1/customer/news_gallery/img1.jpg","assets/image/templet1/customer/news_gallery/img2.jpg","assets/image/templet1/customer/news_gallery/img3.jpg","assets/image/templet1/customer/news_gallery/img4.jpg","assets/image/templet1/customer/news_gallery/img5.jpg","assets/image/templet1/customer/news_gallery/img6.jpg","assets/image/templet1/customer/news_gallery/img7.jpg","assets/image/templet1/customer/news_gallery/img8.jpg","assets/image/templet1/customer/news_gallery/img9.jpg"]
// url2: any= [];
// NewsGallery_array: any[] = [];
// public file2: any;
// newsGallery(event:any) {
//   this.file2 = event.target.files && event.target.files.length;
//   if (this.file2 > 0 && this.file2 < 25) {
//     let i: number = 0;
//     for (const singlefile of event.target.files) {
//       var reader = new FileReader();
//       reader.readAsDataURL(singlefile);
//       this.url2.push(singlefile);
//       this.cf.detectChanges();
//       i++;
//       reader.onload = (event) => {
//         const urls2 = (<FileReader>event.target).result as string;
//         this.NewsGallery_array.push(urls2);
//         this.cf.detectChanges();
//       };
//       console.log(singlefile);
//     }
//       this.selectedFiles =event.target.files
//   }
  
// }


// onclickimg(img: any) {
//   Swal.fire({
//     customClass: {
//       confirmButton: 'btn btn-danger',
//       cancelButton: 'btn btn-success'
//     },
//     buttonsStyling: true,
//     imageUrl: img,
//     imageWidth: 400,
//     imageHeight: 400,
//     imageAlt: 'Custom image',
//     showCancelButton: true,
//     cancelButtonText: 'Cancel!',
//     confirmButtonText: ' Delete it!',
//   }).then((result) => {
//     if (result.isConfirmed) {
//       this.delete_img(this.url2);
      
//     }
//   })
// }

//delete image
// delete_img(array: any) 
// {
//   var arrayLength = array.length + 1;
//   console.log(arrayLength);
//   for (var i = 0; i < array.length; i++) {
//     var item = array[Math.floor(Math.random() * array.length)];
//   console.log(item);
//     array.pop(item);
//     //this.NewsGallery_array.splice(item);
//     //console.log(this.NewsGallery_array);
//   }
// }



// createform(){
//   this.updateForm=this.formBuilder.group({
//     pname:[''],
//     partyname:[''],
//     email:[''],
//     phoneno:[''],
//     whatsappno:[''],
//     officeloction:[''],
//     youtube:[''],
//     insta:[''],
//     facebook:[''],
//     twitterId:[''] ,
//     info:[''],
//     photo:[''],
//     logo:[''],

//   })
// }


// collection(){
//   console.log(this.updateForm.value)
//   const userId=this.route.snapshot.params['id']
//   this.service.update_cuurent(userId).subscribe((data)=>{
//     this.updateForm.patchValue({data});
  

//       console.log("backend data display",data)
// }
//   )
// }
}